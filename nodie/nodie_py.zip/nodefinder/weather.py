"""Automatic shoot temperature from place + local date/time (ESTIMATED, free sources only).

Sources (no paid database):
  Geocoding  1) Open-Meteo geocoding (https://open-meteo.com/en/docs/geocoding-api; free API is
                non-commercial; GeoNames data CC BY 4.0)
             2) Nominatim / OpenStreetMap fallback (ODbL; max 1 req/s, real User-Agent, cache:
                https://operations.osmfoundation.org/policies/nominatim/)
  Temperature 1) PRIMARY: Iowa Environmental Mesonet ASOS archive (US airport METAR observations,
                originating from NWS/FAA = US public domain; IEM is free, asks for attribution):
                https://mesonet.agron.iastate.edu/request/download.phtml
             2) FALLBACK: Open-Meteo historical archive (ERA5 reanalysis grid, CC BY 4.0 data;
                free hosted API is non-commercial only - self-host (AGPL code) or a paid plan for
                commercial): https://open-meteo.com/en/docs/historical-weather-api
Results are cached on disk. Any network failure returns None so the UI falls back to a
manually entered temperature. Values are AIR temperature at the nearest station/grid
point, not powder temperature; label them "estimated".
"""
import json, math, os, re, urllib.parse, urllib.request
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, Optional, Tuple
from zoneinfo import ZoneInfo

UA = "chrono-node-finder/0.3 (personal reloading tool)"
CACHE_PATH = os.environ.get("NODEFINDER_WX_CACHE", os.path.expanduser("~/.cache/nodefinder_weather.json"))
STATES = {"Alabama":"AL","Alaska":"AK","Arizona":"AZ","Arkansas":"AR","California":"CA","Colorado":"CO","Connecticut":"CT",
"Delaware":"DE","Florida":"FL","Georgia":"GA","Hawaii":"HI","Idaho":"ID","Illinois":"IL","Indiana":"IN","Iowa":"IA","Kansas":"KS",
"Kentucky":"KY","Louisiana":"LA","Maine":"ME","Maryland":"MD","Massachusetts":"MA","Michigan":"MI","Minnesota":"MN","Mississippi":"MS",
"Missouri":"MO","Montana":"MT","Nebraska":"NE","Nevada":"NV","New Hampshire":"NH","New Jersey":"NJ","New Mexico":"NM","New York":"NY",
"North Carolina":"NC","North Dakota":"ND","Ohio":"OH","Oklahoma":"OK","Oregon":"OR","Pennsylvania":"PA","Rhode Island":"RI",
"South Carolina":"SC","South Dakota":"SD","Tennessee":"TN","Texas":"TX","Utah":"UT","Vermont":"VT","Virginia":"VA","Washington":"WA",
"West Virginia":"WV","Wisconsin":"WI","Wyoming":"WY"}
ABBR = {v: k for k, v in STATES.items()}

Fetch = Callable[[str], str]


def _http(url: str) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", "replace")


def _cache_load() -> Dict[str, Any]:
    try:
        with open(CACHE_PATH) as f:
            return json.load(f)
    except Exception:
        return {}


def _cache_save(c: Dict[str, Any]) -> None:
    try:
        os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
        with open(CACHE_PATH, "w") as f:
            json.dump(c, f)
    except Exception:
        pass


def haversine_mi(a: Tuple[float, float], b: Tuple[float, float]) -> float:
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 3958.8 * 2 * math.asin(math.sqrt(h))


_TIME = r"(\d{1,2})(?::(\d{2}))?\s*([ap])\.?m\.?"
_DATE = r"(\d{1,2})/(\d{1,2})/(\d{2,4})"


def parse_when_where(text: str) -> Optional[Dict[str, Any]]:
    """Parse e.g. 'shot at 2pm in Langley, WA on 10/1/2026' -> place + naive local datetime."""
    t = text.strip()
    tm, dm = re.search(_TIME, t, re.I), re.search(_DATE, t)
    pm = re.search(r"\bin\s+(.+?)(?:\s+on\b|\s+at\b|$)", t, re.I)
    if not (tm and dm and pm):
        return None
    h = int(tm.group(1)) % 12 + (12 if tm.group(3).lower() == "p" else 0)
    y = int(dm.group(3)); y += 2000 if y < 100 else 0
    return {"place": pm.group(1).strip(" ,."), "local_dt": datetime(y, int(dm.group(1)), int(dm.group(2)), h, int(tm.group(2) or 0))}


def geocode(place: str, fetch: Fetch = _http) -> Optional[Dict[str, Any]]:
    name, _, region = place.partition(",")
    region = region.strip()
    want_state = ABBR.get(region.upper(), region) if region else ""
    try:
        d = json.loads(fetch("https://geocoding-api.open-meteo.com/v1/search?" + urllib.parse.urlencode(
            {"name": name.strip(), "count": 10, "language": "en", "format": "json"})))
        for r in d.get("results", []):
            if not want_state or r.get("admin1", "").lower() == want_state.lower() or r.get("country_code", "").lower() == region.lower():
                return {"lat": r["latitude"], "lon": r["longitude"], "label": f"{r['name']}, {r.get('admin1','')}",
                        "state": STATES.get(r.get("admin1", "")), "tz": r.get("timezone"), "source": "Open-Meteo geocoding"}
    except Exception:
        pass
    try:
        d = json.loads(fetch("https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode(
            {"q": place, "format": "json", "limit": 1, "addressdetails": 1})))
        if d:
            r = d[0]
            st = r.get("address", {}).get("state", "")
            return {"lat": float(r["lat"]), "lon": float(r["lon"]), "label": r.get("display_name", place),
                    "state": STATES.get(st), "tz": None, "source": "Nominatim (© OpenStreetMap, ODbL)"}
    except Exception:
        pass
    return None


def _iem_temp(geo: Dict[str, Any], local_dt: datetime, fetch: Fetch) -> Optional[Dict[str, Any]]:
    if not geo.get("state"):
        return None
    net = json.loads(fetch(f"https://mesonet.agron.iastate.edu/geojson/network/{geo['state']}_ASOS.geojson"))
    stations = []
    for f in net.get("features", []):
        lon, lat = f["geometry"]["coordinates"][:2]
        p = f["properties"]
        stations.append((haversine_mi((geo["lat"], geo["lon"]), (lat, lon)), p.get("sid"), p.get("sname"), p.get("tzname")))
    stations.sort()
    for dist, sid, sname, tzname in stations[:3]:
        tz = geo.get("tz") or tzname or "UTC"
        d0 = local_dt - timedelta(hours=2); d1 = local_dt + timedelta(hours=2)
        q = urllib.parse.urlencode({"station": sid, "data": "tmpf", "tz": tz, "format": "onlycomma", "report_type": "3",
                                    "year1": d0.year, "month1": d0.month, "day1": d0.day,
                                    "year2": d1.year, "month2": d1.month, "day2": d1.day})
        q += f"&hour1={d0.hour}&hour2={d1.hour}" if d0.date() == d1.date() else ""
        best = None
        for line in fetch("https://mesonet.agron.iastate.edu/cgi-bin/request/asos.py?" + q).splitlines()[1:]:
            parts = line.split(",")
            if len(parts) < 3 or parts[2] in ("", "M"):
                continue
            try:
                t = datetime.strptime(parts[1], "%Y-%m-%d %H:%M")
            except ValueError:
                continue
            gap = abs((t - local_dt).total_seconds()) / 60
            if gap <= 90 and (best is None or gap < best[0]):
                best = (gap, float(parts[2]), parts[1])
        if best:
            return {"temp_f": round(best[1], 1), "source": "IEM ASOS archive (NWS/FAA METAR, public domain)",
                    "station": f"K{sid}" if len(sid) == 3 and sid.isalpha() else sid, "station_name": sname,
                    "distance_mi": round(dist, 1), "obs_time_local": best[2], "minutes_from_request": int(best[0])}
    return None


def _openmeteo_temp(geo: Dict[str, Any], local_dt: datetime, fetch: Fetch) -> Optional[Dict[str, Any]]:
    day = local_dt.strftime("%Y-%m-%d")
    d = json.loads(fetch("https://archive-api.open-meteo.com/v1/archive?" + urllib.parse.urlencode({
        "latitude": geo["lat"], "longitude": geo["lon"], "start_date": day, "end_date": day,
        "hourly": "temperature_2m", "temperature_unit": "fahrenheit", "timezone": geo.get("tz") or "auto"})))
    h = d.get("hourly", {})
    key = local_dt.replace(minute=0).strftime("%Y-%m-%dT%H:00")
    if key in h.get("time", []):
        v = h["temperature_2m"][h["time"].index(key)]
        if v is not None:
            return {"temp_f": round(float(v), 1), "source": "Open-Meteo archive (ERA5 reanalysis, CC BY 4.0; non-commercial free tier)",
                    "station": "model grid", "station_name": f"grid {d.get('latitude')},{d.get('longitude')}",
                    "distance_mi": round(haversine_mi((geo["lat"], geo["lon"]), (d.get("latitude", geo["lat"]), d.get("longitude", geo["lon"]))), 1),
                    "obs_time_local": key, "minutes_from_request": local_dt.minute}
    return None


def lookup_shoot_temp(place: str, local_dt: datetime, fetch: Fetch = _http, use_cache: bool = True) -> Dict[str, Any]:
    """Return {'ok': True, temp_f, source, station, distance_mi, estimated: True, ...} or {'ok': False, reason}."""
    key = f"{place.lower().strip()}|{local_dt:%Y-%m-%d %H:%M}"
    cache = _cache_load() if use_cache else {}
    if key in cache:
        return dict(cache[key], cached=True)
    geo = geocode(place, fetch)
    if not geo:
        return {"ok": False, "reason": f"Couldn't find '{place}'. Enter the temperature manually."}
    res = None
    for fn in (_iem_temp, _openmeteo_temp):
        try:
            res = fn(geo, local_dt, fetch)
        except Exception:
            res = None
        if res:
            break
    if not res:
        return {"ok": False, "reason": "No weather data reachable (offline, or date too recent/old). Enter the temperature manually.",
                "place": geo["label"]}
    out = dict(res, ok=True, estimated=True, place=geo["label"], lat=geo["lat"], lon=geo["lon"], geocoder=geo["source"],
               requested_local=f"{local_dt:%Y-%m-%d %H:%M}",
               label=f"≈{res['temp_f']}°F (estimated air temp, {res['station']} {res['distance_mi']} mi away)")
    if use_cache:
        cache[key] = out
        _cache_save(cache)
    return out


def lookup_from_text(text: str, fetch: Fetch = _http, use_cache: bool = True) -> Dict[str, Any]:
    p = parse_when_where(text)
    if not p:
        return {"ok": False, "reason": "Try: 'shot at 2pm in Langley, WA on 10/1/2026'."}
    return lookup_shoot_temp(p["place"], p["local_dt"], fetch, use_cache)
