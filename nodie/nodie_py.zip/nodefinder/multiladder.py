"""Round-robin / multiple ladders in one chrono file.

The user lists each ladder (bullet, weight, charge start/step/count, optional min/max fps
bounds). Shots are de-interleaved by order: shot i belongs to round i // N (N = ladder count),
and each round fires one step of every ladder. Shooters often reverse or shuffle the order
within a round, so for each round we choose the permutation of ladders that best fits each
ladder's linear velocity trend (iterated), subject to optional hard min/max bounds.
Rounds whose best and second-best assignments are close, or whose residuals are large, are
FLAGGED as ambiguous. Manual overrides ({shot_num: ladder_index or None to exclude}) always win.
"""
import itertools
from typing import Any, Dict, List, Optional

from .engine import compute_ladder_fit


def _fit(points):
    if len(points) < 2:
        return None
    xs, ys = zip(*points)
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    sxx = sum((x - mx) ** 2 for x in xs)
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx if sxx else 0.0
    return my - b * mx, b


def deinterleave(shots: List[Dict[str, Any]], ladders: List[Dict[str, Any]],
                 overrides: Optional[Dict[int, Optional[int]]] = None,
                 ambiguity_ratio: float = 0.6, outlier_fps: float = 40.0,
                 order_mode: str = "serpentine", exclude_fps: Optional[List[float]] = None) -> Dict[str, Any]:
    """order_mode: 'fixed' (same order every round), 'serpentine' (each round forward OR reversed,
    chosen by fit - the common way people shoot round-robin), or 'any' (any order per round).
    exclude_fps: velocities of sighters/foulers to drop (matched within 0.1 fps)."""
    n = len(ladders)
    overrides = overrides or {}
    excluded_pre = []
    if exclude_fps:
        todo = list(exclude_fps)
        kept = []
        for s in shots:
            m = next((x for x in todo if abs(s["velocity_fps"] - x) <= 0.1), None)
            if m is not None:
                todo.remove(m)
                excluded_pre.append({"shot_num": s["shot_num"], "velocity_fps": s["velocity_fps"], "reason": "user-listed sighter/fouler"})
            else:
                kept.append(s)
        shots = kept
    rounds = [shots[i:i + n] for i in range(0, len(shots), n)]
    charge = lambda j, r: round(float(ladders[j]["start_gr"]) + r * float(ladders[j]["step_gr"]), 2)
    fwd = tuple(range(n))

    def perms_for(k):
        if order_mode == "fixed":
            return [fwd[:k]]
        if order_mode == "serpentine" and k == n:
            return [fwd, fwd[::-1]]
        return list(itertools.permutations(range(n), k))
    chosen = [tuple(range(n))] * len(rounds)
    lo = [l.get("min_fps") for l in ladders]
    hi = [l.get("max_fps") for l in ladders]

    def ok(j, v):
        return (lo[j] is None or v >= lo[j] - 0.05) and (hi[j] is None or v <= hi[j] + 0.05)

    fits = [None] * n
    costs_all = []
    for _ in range(6):
        costs_all = []
        for r, rnd in enumerate(rounds):
            scored = []
            for p in perms_for(len(rnd)):
                c = 0.0
                for k, s in enumerate(rnd):
                    j = p[k]
                    v = s["velocity_fps"]
                    if not ok(j, v):
                        c += 1e4
                    if fits[j]:
                        a, b = fits[j]
                        c += (v - (a + b * charge(j, r))) ** 2
                    else:  # bootstrap: prefer original order
                        c += 0 if j == k else 1.0
                scored.append((c, p))
            scored.sort(key=lambda t: t[0])
            chosen[r] = scored[0][1]
            costs_all.append(scored[:2])
        new = []
        for j in range(n):
            pts = [(charge(j, r), s["velocity_fps"]) for r, rnd in enumerate(rounds)
                   for k, s in enumerate(rnd) if chosen[r][k] == j]
            # robust: drop worst 1 point if >= 6 points
            f = _fit(pts)
            if f and len(pts) >= 6:
                res = sorted(pts, key=lambda p: -abs(p[1] - (f[0] + f[1] * p[0])))
                f = _fit(res[1:])
            new.append(f)
        if new == fits:
            break
        fits = new

    assign, flags = [], []
    for r, rnd in enumerate(rounds):
        (c1, p1), *rest = costs_all[r]
        c2 = rest[0][0] if rest else float("inf")
        close = c1 > 0 and (c1 / c2) > ambiguity_ratio
        for k, s in enumerate(rnd):
            j = p1[k]
            sn = s["shot_num"]
            exp = fits[j][0] + fits[j][1] * charge(j, r) if fits[j] else None
            resid = round(s["velocity_fps"] - exp, 1) if exp is not None else None
            reasons = []
            if close:
                reasons.append(f"round {r+1}: alternative order nearly as good")
            if resid is not None and abs(resid) > outlier_fps:
                reasons.append(f"{resid:+.0f} fps off ladder trend")
            if not ok(j, s["velocity_fps"]):
                reasons.append("outside user min/max bounds")
            row = {"shot_num": sn, "round": r + 1, "velocity_fps": s["velocity_fps"],
                   "timestamp": s.get("timestamp", ""), "ladder": j, "ladder_name": ladders[j]["name"],
                   "charge_gr": charge(j, r), "residual_fps": resid, "flags": reasons,
                   "excluded": bool(reasons and any("off ladder" in x for x in reasons)),
                   "override": False}
            if sn in overrides:
                ov = overrides[sn]
                row["override"] = True
                if ov is None:
                    row["excluded"] = True
                else:
                    row.update(ladder=ov, ladder_name=ladders[ov]["name"], charge_gr=charge(ov, r), excluded=False)
            assign.append(row)
            if reasons:
                flags.append(row)
    order = [[ladders[j]["name"] for j in p] for p in chosen]
    counts = {l["name"]: sum(1 for a in assign if a["ladder_name"] == l["name"] and not a["excluded"]) for l in ladders}
    expected = {l["name"]: l.get("count") for l in ladders}
    short = {k: (counts[k], expected[k]) for k in counts if expected[k] and counts[k] != expected[k]}
    return {"assignments": assign, "flags": flags, "round_orders": order, "pre_excluded": excluded_pre,
            "counts": counts, "count_mismatch": short}


def flat_spots(points: List[Dict[str, Any]], slope: float, step: float) -> List[str]:
    pts = sorted(points, key=lambda p: p["charge_gr"])
    out = []
    for a, b in zip(pts, pts[1:]):
        if abs(b["velocity_fps"] - a["velocity_fps"]) <= max(3.0, abs(slope * step) / 3.0):
            out.append(f"{a['charge_gr']:.1f}–{b['charge_gr']:.1f} gr ({a['velocity_fps']:.0f}/{b['velocity_fps']:.0f} fps)")
    return out


def analyze_multi(shots, ladders, cartridge, barrel_length_in, overrides=None, order_mode="serpentine",
                  exclude_fps=None, **target_kw) -> Dict[str, Any]:
    from .targets import compute_velocity_targets
    d = deinterleave(shots, ladders, overrides, order_mode=order_mode, exclude_fps=exclude_fps)
    results = []
    for j, lad in enumerate(ladders):
        pts = [{"shot_num": a["shot_num"], "charge_gr": a["charge_gr"], "velocity_fps": a["velocity_fps"]}
               for a in d["assignments"] if a["ladder"] == j and not a["excluded"]]
        fit = compute_ladder_fit(pts)
        avg = sum(p["velocity_fps"] for p in pts) / len(pts) if pts else 0.0
        vt = compute_velocity_targets(cartridge, float(lad["weight_gr"]), barrel_length_in, avg, **target_kw)
        near = []
        for p in pts:
            for t in vt["targets"]:
                if abs(p["velocity_fps"] - t["target_fps_at_temp"]) <= 12:
                    near.append({"charge_gr": p["charge_gr"], "velocity_fps": p["velocity_fps"], "node": t["node"],
                                 "over_limit": t["over_limit"]})
        from .engine import estimate_psi_at_velocity, CARTRIDGES
        lim = vt["assumptions"]["max_psi"]
        over_steps = []
        for p in pts:
            psi = estimate_psi_at_velocity(cartridge, float(lad["weight_gr"]), barrel_length_in, p["velocity_fps"],
                                           target_kw.get("case_h2o_gr"))
            p["est_psi"] = psi
            if psi > lim:
                over_steps.append(p["charge_gr"])
        results.append({
            "over_limit_steps_gr": over_steps,
            "name": lad["name"], "weight_gr": lad["weight_gr"], "shots_used": len(pts),
            "r_squared": fit and fit["r_squared"], "rmse_fps": fit and fit["rmse_fps"],
            "slope_fps_per_gr": fit and fit["slope_fps_per_gr"],
            "flat_spots": flat_spots(pts, fit["slope_fps_per_gr"], float(lad["step_gr"])) if fit else [],
            "picks": vt["picks"], "steps_near_nodes": near, "targets": vt["targets"],
            "points": sorted(pts, key=lambda p: p["charge_gr"]),
        })
    return {"deinterleave": d, "ladders": results}


def parse_ladder_spec(text: str) -> List[Dict[str, Any]]:
    """One ladder per line: name, weight_gr, start_gr, step_gr, count[, min_fps, max_fps]."""
    out = []
    for line in (text or "").splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 5 or not parts[0]:
            continue
        d = {"name": parts[0], "weight_gr": float(parts[1]), "start_gr": float(parts[2]),
             "step_gr": float(parts[3]), "count": int(float(parts[4]))}
        if len(parts) >= 7 and parts[5] and parts[6]:
            d["min_fps"], d["max_fps"] = float(parts[5]), float(parts[6])
        out.append(d)
    return out


def parse_overrides(text: str) -> Dict[int, Optional[int]]:
    """'45=2, 47=x' -> shot 45 to ladder #2 (1-based), shot 47 excluded."""
    out: Dict[int, Optional[int]] = {}
    for tok in (text or "").replace(";", ",").split(","):
        if "=" in tok:
            a, b = (t.strip() for t in tok.split("=", 1))
            out[int(a)] = None if b.lower() in ("x", "exclude", "-") else int(b) - 1
    return out
