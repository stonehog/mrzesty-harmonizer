"""Ranked VELOCITY TARGETS: OBT nodes x pressure limit x temperature (all ESTIMATES).

Easy by default; each optional Advanced input refines one factor:

* barrel_contour -> OBT node timing via a stiffness factor.
  Chris Long's OBT model (http://www.the-long-family.com/OBT_paper.htm) derives node
  times from the speed of sound in steel and barrel length only; it assumes a
  ~sporter/medium contour. Field reports (Long; Varmint Al barrel-tuner FEA,
  http://www.varmintal.com/ahunt.htm) show heavier, stiffer barrels shift/widen the
  optimal window slightly. We model this as a SMALL multiplicative factor on node time
  (light 0.985, medium 1.000, heavy 1.015). This is an APPROXIMATION, not physics
  from first principles; treat it as +/- ~1% fps.
* case_h2o_gr -> replaces the default case-capacity factor (P ~ (V_default/V)^1.4).
* coal_in -> seating depth: each inch shorter than the reference COAL removes
  bore_area x depth of powder space (1 in^3 = 252.9 gr H2O), raising pressure.
* temps -> v_std = v_measured - k*(T_session - 59F); target_at_T = target_std + k*(T_shoot - 59F).
  k = powder temp coefficient fps/F. Default 1.5 fps/F is a GENERIC ASSUMPTION
  (non-temp-stable extruded powders typically ~1-2 fps/F; Hodgdon Extreme "temp
  stable" powders claim far less). Measure your own lot when possible.

POLICY: velocity targets only. NO charge-weight recommendations. Work up from
published load data and stop at the first pressure sign.
"""
from typing import Any, Dict, List, Optional
import math

STD_TEMP_F = 59.0
DEFAULT_TEMP_COEF = 1.5
GR_H2O_PER_IN3 = 252.9
CONTOUR_FACTORS = {"light": 0.985, "medium": 1.0, "heavy": 1.015}


def contour_velocity_scale(contour: Optional[str]) -> float:
    """Node-time factor f -> velocity scale f^-0.82 (same V~t^-0.82 law as compute_obt_nodes)."""
    f = CONTOUR_FACTORS.get((contour or "medium").lower(), 1.0)
    return f ** -0.82


def effective_h2o(spec: Dict[str, Any], case_h2o_gr: Optional[float], coal_in: Optional[float]) -> float:
    h2o = float(case_h2o_gr) if (case_h2o_gr and case_h2o_gr > 5) else float(spec["case_h2o_gr"])
    if coal_in and coal_in > 0.5:
        area = math.pi * (spec["bullet_dia_in"] / 2.0) ** 2
        h2o -= (float(spec["coal_in"]) - float(coal_in)) * area * GR_H2O_PER_IN3
    return max(5.0, h2o)


def temp_adjust(v: float, from_f: float, to_f: float, coef: float) -> float:
    return v + coef * (to_f - from_f)


def compute_velocity_targets(
    cartridge: str, bullet_weight_gr: float, barrel_length_in: float, measured_avg_fps: float,
    max_psi: Optional[float] = None, session_temp_f: Optional[float] = None,
    shoot_temp_f: Optional[float] = None, barrel_contour: Optional[str] = None,
    case_h2o_gr: Optional[float] = None, coal_in: Optional[float] = None,
    temp_coef_fps_per_f: Optional[float] = None, powder_name: str = "",
    daily_band_pct: tuple = (85.0, 90.0), hunting_max_pct: float = 95.0,
) -> Dict[str, Any]:
    from .engine import CARTRIDGES, compute_obt_nodes, estimate_psi_at_velocity

    spec = CARTRIDGES[cartridge]
    coef_user = temp_coef_fps_per_f is not None and temp_coef_fps_per_f >= 0
    coef = float(temp_coef_fps_per_f) if coef_user else DEFAULT_TEMP_COEF
    t_sess = float(session_temp_f) if session_temp_f is not None else None
    t_shoot = float(shoot_temp_f) if shoot_temp_f is not None else t_sess
    limit = float(spec["saami_max_psi"])
    if max_psi and 0 < float(max_psi) < limit:
        limit = float(max_psi)
    h2o_eff = effective_h2o(spec, case_h2o_gr, coal_in)
    vscale = contour_velocity_scale(barrel_contour)
    v_std_meas = temp_adjust(measured_avg_fps, t_sess, STD_TEMP_F, coef) if t_sess is not None else measured_avg_fps

    obt = compute_obt_nodes(cartridge, bullet_weight_gr, barrel_length_in)
    rows: List[Dict[str, Any]] = []
    for n in obt["nodes"]:
        v_std = n["target_fps"] * vscale  # OBT targets are taken as standard-temp velocities
        v_at = temp_adjust(v_std, STD_TEMP_F, t_shoot, coef) if t_shoot is not None else v_std
        psi = estimate_psi_at_velocity(cartridge, bullet_weight_gr, barrel_length_in, v_at, h2o_eff)
        pct = psi / limit
        over = psi > limit
        # score: full node, pressure in 80-97% band (efficient but with margin), near measured
        score = (2.0 if n["is_full_node"] else 1.0)
        score += 1.5 if 0.80 <= pct <= 0.97 else (0.5 if pct < 0.80 else 0.0)
        score -= min(1.5, abs(v_std - v_std_meas) / 200.0)
        rows.append({
            "node": n["node"], "is_full_node": n["is_full_node"],
            "time_ms": round(n["time_ms"] * CONTOUR_FACTORS.get((barrel_contour or "medium").lower(), 1.0), 4),
            "target_fps_59f": int(round(v_std)),
            "target_fps_at_temp": int(round(v_at)),
            "shoot_temp_f": t_shoot,
            "est_psi": psi, "pct_of_limit": round(pct * 100, 1),
            "over_limit": over, "score": round(score, 2),
        })
    ok = sorted([r for r in rows if not r["over_limit"]], key=lambda r: -r["score"])
    for i, r in enumerate(ok, 1):
        r["rank"] = i
        r["confidence"] = "High" if (r["is_full_node"] and r["pct_of_limit"] <= 97) else ("Medium" if r["is_full_node"] or r["pct_of_limit"] <= 90 else "Low")
    over_rows = [r for r in rows if r["over_limit"]]
    for r in over_rows:
        r["rank"], r["confidence"] = None, "OVER LIMIT"

    picks = select_picks(ok, daily_band_pct, hunting_max_pct)
    used = {
        "temperature": t_sess is not None, "barrel_contour": bool(barrel_contour),
        "case_h2o": bool(case_h2o_gr and case_h2o_gr > 5), "coal": bool(coal_in and coal_in > 0.5),
        "powder_temp_coef": coef_user,
    }
    n_used = sum(used.values())
    level = "Best" if n_used >= 4 else ("Improved" if n_used >= 1 else "Basic")
    hints = {
        "temperature": "Enter session temp °F to normalize velocity to 59°F and re-project targets.",
        "barrel_contour": "Pick barrel contour to refine node timing (~±1%).",
        "case_h2o": "Enter measured fired-case H2O capacity to sharpen the pressure estimate.",
        "coal": "Enter COAL to account for seating depth in the pressure estimate.",
        "powder_temp_coef": f"Enter your powder's temp coefficient (using generic {DEFAULT_TEMP_COEF} fps/°F assumption).",
    }
    return {
        "picks": picks,
        "targets": ok + over_rows,
        "accuracy_level": level, "inputs_used": used,
        "next_improvements": [hints[k] for k, v in used.items() if not v],
        "assumptions": {
            "max_psi": int(limit), "temp_coef_fps_per_f": coef,
            "temp_coef_is_assumption": not coef_user, "effective_case_h2o_gr": round(h2o_eff, 2),
            "contour_velocity_scale": round(vscale, 4), "measured_avg_at_59f": round(v_std_meas, 1),
            "powder": powder_name,
        },
        "policy": "VELOCITY TARGETS ONLY — no charge weights. Work up from published load data "
                  "(start low, watch for pressure signs) to reach the target velocity at your shooting temp.",
    }


def select_picks(in_limit: List[Dict[str, Any]], daily_band_pct=(85.0, 90.0), hunting_max_pct: float = 95.0) -> Dict[str, Any]:
    """Daily Driver: node nearest the daily % band (inside band preferred, never above hunting cap).
    Hunting: highest-velocity node with est. PSI <= hunting_max_pct of limit."""
    lo, hi = float(daily_band_pct[0]), float(daily_band_pct[1])
    daily_pool = [r for r in in_limit if r["pct_of_limit"] <= hunting_max_pct]
    daily = None
    if daily_pool:
        def dist(r):
            p = r["pct_of_limit"]
            return 0.0 if lo <= p <= hi else min(abs(p - lo), abs(p - hi))
        daily = min(daily_pool, key=lambda r: (dist(r), -r["is_full_node"]))
    hunt_pool = [r for r in in_limit if r["pct_of_limit"] <= hunting_max_pct]
    hunting = max(hunt_pool, key=lambda r: r["target_fps_59f"]) if hunt_pool else None
    d_in = daily is not None and lo <= daily["pct_of_limit"] <= hi
    return {
        "daily_driver": daily, "daily_in_band": d_in,
        "daily_note": ("No node falls under the hunting cap; no Daily Driver pick." if daily is None else
                       ("" if d_in else f"No node falls inside {lo:g}-{hi:g}% of limit; nearest is shown.")),
        "hunting": hunting,
        "hunting_note": "" if hunting else f"No node is at or below {hunting_max_pct:g}% of the limit.",
        "daily_band_pct": [lo, hi], "hunting_max_pct": hunting_max_pct,
    }
