"""HTTP & Optional Flask Server for Nodie.

Works out-of-the-box with zero external web framework required (uses Python's built-in
http.server + cgi/multipart parser) AND exposes a standard WSGI/Flask app if Flask is installed.
"""
from __future__ import annotations

import email.parser
import json
import os
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Dict, Tuple
from urllib.parse import parse_qs, urlparse

from .engine import CARTRIDGES, analyze_session

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
STATIC_DIR = os.path.join(os.path.dirname(__file__), "static")
SAMPLES_DIR = os.path.join(BASE_DIR, "samples")

SAMPLE_PRESETS: Dict[str, Dict[str, Any]] = {
    "factory_7prc_160cx": {
        "id": "factory_7prc_160cx",
        "title": "7mm PRC · Hornady Outfitter 160gr CX Factory Ammo (3 shots, Garmin .fit)",
        "filename": "7PRC_Hornady_Outfitter_160CX_factory_08-21-2024_16-05-45.fit",
        "cartridge": "7mm PRC",
        "bullet_weight_gr": 160,
        "barrel_length_in": 24.0,
        "ammo_type": "factory",
        "factory_label": "Hornady Outfitter 160gr CX Factory",
        "powder_name": "",
        "charges_text": "",
        "start_charge_gr": None,
        "step_charge_gr": None,
    },
    "factory_7prc_175eldx": {
        "id": "factory_7prc_175eldx",
        "title": "7mm PRC · Hornady Precision Hunter 175gr ELD-X Factory (3 shots, Garmin .fit)",
        "filename": "7PRC_Hornady_175ELDX_factory_08-21-2024_16-41-33.fit",
        "cartridge": "7mm PRC",
        "bullet_weight_gr": 175,
        "barrel_length_in": 24.0,
        "ammo_type": "factory",
        "factory_label": "Hornady Precision Hunter 175gr ELD-X Factory",
        "powder_name": "",
        "charges_text": "",
        "start_charge_gr": None,
        "step_charge_gr": None,
    },
    "ladder_7prc_195eol_n565": {
        "id": "ladder_7prc_195eol_n565",
        "title": "7mm PRC · 195gr Berger EOL + Viht N565 10-Step Handload Ladder (Garmin .fit)",
        "filename": "7PRC_195EOL_N565_ladder_08-22-2024_13-38-07.fit",
        "cartridge": "7mm PRC",
        "bullet_weight_gr": 195,
        "barrel_length_in": 24.0,
        "ammo_type": "handload",
        "factory_label": "",
        "powder_name": "Vihtavuori N565",
        "charges_text": "63.4, 63.8, 64.2, 64.6, 65.0, 65.4, 65.8, 66.2, 66.6, 67.0",
        "start_charge_gr": 63.4,
        "step_charge_gr": 0.4,
    },
    "ladder_7prc_175eldx_n560": {
        "id": "ladder_7prc_175eldx_n560",
        "title": "7mm PRC · 175gr ELD-X + Viht N560 10-Step Handload Ladder (Garmin .fit)",
        "filename": "7PRC_175ELDX_N560_ladder_08-22-2024_14-30-39.fit",
        "cartridge": "7mm PRC",
        "bullet_weight_gr": 175,
        "barrel_length_in": 24.0,
        "ammo_type": "handload",
        "factory_label": "",
        "powder_name": "Vihtavuori N560",
        "charges_text": "63.4, 63.8, 64.2, 64.6, 65.0, 65.4, 65.8, 66.2, 66.6, 67.0",
        "start_charge_gr": 63.4,
        "step_charge_gr": 0.4,
    },
    "group_65cm_144smk_n150": {
        "id": "group_65cm_144smk_n150",
        "title": "6.5 Creedmoor · 24\" T/C LRR 144gr Sierra MK + N150 5-Shot Group (Garmin .fit)",
        "filename": "65CM_144SMK_N150_group_08-14-2026_11-11-49.fit",
        "cartridge": "6.5 Creedmoor",
        "bullet_weight_gr": 144,
        "barrel_length_in": 24.0,
        "ammo_type": "handload",
        "factory_label": "",
        "powder_name": "Vihtavuori N150",
        "charges_text": "38.0, 38.0, 38.0, 38.0, 38.0",
        "start_charge_gr": 38.0,
        "step_charge_gr": 0.0,
    },
    "roundrobin_65cm_4ladder": {
        "id": "roundrobin_65cm_4ladder",
        "title": "6.5 Creedmoor · 4 ladders shot round-robin, N150, 5/12/2026 Langley WA (Garmin .fit)",
        "filename": "65CM_4ladder_roundrobin_05-12-2026_14-46-48.fit",
        "cartridge": "6.5 Creedmoor",
        "bullet_weight_gr": 140,
        "barrel_length_in": 24.0,
        "ammo_type": "handload",
        "factory_label": "",
        "powder_name": "Vihtavuori N150",
        "charges_text": "",
        "start_charge_gr": None,
        "step_charge_gr": None,
        "session_temp_f": 73,
        "multi_ladders": "140 SMK, 140, 38.0, 0.2, 12\n144 SMK, 144, 37.2, 0.2, 12, 2670.1, 2776.5\n147 ELD-M, 147, 36.6, 0.2, 12, 2579.5, 2717.0\n145 MB, 145, 36.6, 0.2, 12, 2621.0, 2729.4",
        "sighter_fps": "2687.9, 2697.5",
    },
    "csv_308_ladder": {
        "id": "csv_308_ladder",
        "title": ".308 Win · 22\" Barrel 168gr SMK 5-Step CSV Ladder (sample_garmin_csv.csv)",
        "filename": "sample_garmin_csv.csv",
        "cartridge": ".308 Win",
        "bullet_weight_gr": 168,
        "barrel_length_in": 22.0,
        "ammo_type": "handload",
        "factory_label": "",
        "powder_name": "Vihtavuori N150",
        "charges_text": "41.2, 41.5, 41.8, 42.1, 42.4",
        "start_charge_gr": 41.2,
        "step_charge_gr": 0.3,
    },
}


def parse_multipart_form(content_type: str, body: bytes) -> Tuple[Dict[str, str], Dict[str, Tuple[str, bytes]]]:
    """Parse multipart/form-data using Python standard library email.parser."""
    fields: Dict[str, str] = {}
    files: Dict[str, Tuple[str, bytes]] = {}
    header_bytes = f"Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n".encode("utf-8")
    msg = email.parser.BytesParser().parsebytes(header_bytes + body)
    if not msg.is_multipart():
        return fields, files
    for part in msg.get_payload():
        cd = part.get("Content-Disposition", "")
        if "form-data" not in cd:
            continue
        name = part.get_param("name", header="content-disposition")
        filename = part.get_param("filename", header="content-disposition")
        payload = part.get_payload(decode=True) or b""
        if not name:
            continue
        if filename is not None and filename != "":
            files[name] = (filename, payload)
        else:
            fields[name] = payload.decode("utf-8", errors="replace")
    return fields, files


def _float_or_none(val: Any) -> Any:
    if val is None or str(val).strip() == "":
        return None
    try:
        return float(val)
    except ValueError:
        return None


def handle_analyze_request(fields: Dict[str, str], files: Dict[str, Tuple[str, bytes]]) -> Dict[str, Any]:
    preset_id = fields.get("sample_preset", "").strip()
    if preset_id and preset_id in SAMPLE_PRESETS and "chrono_file" not in files:
        p = SAMPLE_PRESETS[preset_id]
        sample_path = os.path.join(SAMPLES_DIR, p["filename"])
        with open(sample_path, "rb") as f:
            file_bytes = f.read()
        filename = p["filename"]
        cartridge = fields.get("cartridge") or p["cartridge"]
        b_wt = _float_or_none(fields.get("bullet_weight_gr")) or p["bullet_weight_gr"]
        b_len = _float_or_none(fields.get("barrel_length_in")) or p["barrel_length_in"]
        ammo_type = fields.get("ammo_type") or p["ammo_type"]
        factory_label = fields.get("factory_label", p["factory_label"])
        powder_name = fields.get("powder_name", p["powder_name"])
        charges_text = fields.get("charges_text", p["charges_text"])
        start_chg = _float_or_none(fields.get("start_charge_gr"))
        if start_chg is None:
            start_chg = p["start_charge_gr"]
        step_chg = _float_or_none(fields.get("step_charge_gr"))
        if step_chg is None:
            step_chg = p["step_charge_gr"]
        h2o_ovr = _float_or_none(fields.get("case_h2o_override_gr"))
    else:
        if "chrono_file" not in files:
            raise ValueError("Please upload a Garmin .fit or .csv chronograph file (or click one of the preloaded test files).")
        filename, file_bytes = files["chrono_file"]
        cartridge = fields.get("cartridge", "6.5 Creedmoor")
        b_wt = _float_or_none(fields.get("bullet_weight_gr")) or 0.0
        b_len = _float_or_none(fields.get("barrel_length_in")) or 24.0
        ammo_type = fields.get("ammo_type", "factory")
        factory_label = fields.get("factory_label", "")
        powder_name = fields.get("powder_name", "")
        charges_text = fields.get("charges_text", "")
        start_chg = _float_or_none(fields.get("start_charge_gr"))
        step_chg = _float_or_none(fields.get("step_charge_gr"))
        h2o_ovr = _float_or_none(fields.get("case_h2o_override_gr"))

    result = analyze_session(
        cartridge=cartridge,
        bullet_weight_gr=b_wt,
        barrel_length_in=b_len,
        file_bytes=file_bytes,
        filename=filename,
        ammo_type=ammo_type,
        factory_label=factory_label,
        powder_name=powder_name,
        charges_text=charges_text,
        start_charge_gr=start_chg,
        step_charge_gr=step_chg,
        case_h2o_override_gr=h2o_ovr,
        max_psi=_float_or_none(fields.get("max_psi")),
        session_temp_f=_float_or_none(fields.get("session_temp_f")),
        shoot_temp_f=_float_or_none(fields.get("shoot_temp_f")),
        barrel_contour=(fields.get("barrel_contour") or None),
        coal_in=_float_or_none(fields.get("coal_in")),
        temp_coef_fps_per_f=_float_or_none(fields.get("temp_coef_fps_per_f")),
        daily_lo_pct=_float_or_none(fields.get("daily_lo_pct")),
        daily_hi_pct=_float_or_none(fields.get("daily_hi_pct")),
        hunting_max_pct=_float_or_none(fields.get("hunting_max_pct")),
        where_when=fields.get("where_when", "") or "",
    )
    spec_text = fields.get("multi_ladders", "") or ""
    if spec_text.strip():
        from .multiladder import analyze_multi, parse_ladder_spec, parse_overrides
        lads = parse_ladder_spec(spec_text)
        if len(lads) >= 2:
            sighters = [float(x) for x in (fields.get("sighter_fps", "") or "").replace(";", ",").split(",") if x.strip()]
            inp = result["inputs"]
            result["multi"] = analyze_multi(
                result["chrono"]["shots"], lads, cartridge, inp["barrel_length_in"],
                overrides=parse_overrides(fields.get("multi_overrides", "")),
                order_mode=fields.get("multi_order", "serpentine") or "serpentine",
                exclude_fps=sighters,
                session_temp_f=result["velocity_targets"]["inputs_used"]["temperature"] and
                (_float_or_none(fields.get("session_temp_f")) or (result.get("weather") or {}).get("temp_f")) or None,
                max_psi=_float_or_none(fields.get("max_psi")),
            )
    return result


class NodeFinderHTTPHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: Any) -> None:
        return  # Keep console clean

    def _send_json(self, data: Any, status: int = 200) -> None:
        raw = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _send_file(self, path: str, content_type: str) -> None:
        with open(path, "rb") as f:
            raw = f.read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        p = parsed.path
        if p in ("/", "/index.html"):
            self._send_file(os.path.join(STATIC_DIR, "index.html"), "text/html; charset=utf-8")
        elif p == "/api/cartridges":
            self._send_json({"cartridges": CARTRIDGES, "samples": SAMPLE_PRESETS})
        elif p == "/api/health":
            self._send_json({"status": "ok", "app": "Nodie"})
        elif p.startswith("/samples/"):
            fn = os.path.basename(p)
            sp = os.path.join(SAMPLES_DIR, fn)
            if os.path.isfile(sp):
                self._send_file(sp, "application/octet-stream")
            else:
                self._send_json({"error": "Sample not found"}, 404)
        else:
            self._send_json({"error": "Not found"}, 404)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path != "/api/analyze":
            self._send_json({"error": "Not found"}, 404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = self.rfile.read(length) if length > 0 else b""
            ctype = self.headers.get("Content-Type", "")
            if "multipart/form-data" in ctype:
                fields, files = parse_multipart_form(ctype, body)
            elif "application/json" in ctype:
                payload = json.loads(body.decode("utf-8"))
                fields = {k: str(v) if v is not None else "" for k, v in payload.items()}
                files = {}
            else:
                qs = parse_qs(body.decode("utf-8"))
                fields = {k: v[0] for k, v in qs.items()}
                files = {}
            res = handle_analyze_request(fields, files)
            self._send_json(res, 200)
        except Exception as e:
            self._send_json({"error": str(e), "trace": traceback.format_exc()}, 400)


def run_server(host: str = "0.0.0.0", port: int = 5174) -> None:
    server = ThreadingHTTPServer((host, port), NodeFinderHTTPHandler)
    print(f"Nodie listening on http://{host}:{port}")
    server.serve_forever()


if __name__ == "__main__":
    import argparse

    ap = argparse.ArgumentParser(description="Run Nodie")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5174)
    args = ap.parse_args()
    run_server(args.host, args.port)
