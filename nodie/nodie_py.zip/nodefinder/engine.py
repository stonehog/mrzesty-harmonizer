"""Deterministic ballistics, OBT node, pressure estimate, and chrono parser engine.

Rules enforced:
- NO standard deviation (mean-centered dispersion) is ever computed, stored, or returned.
  Only Average Velocity (fps) and Extreme Spread (ES = Max - Min fps) are reported.
- Pressure values are strictly labeled ESTIMATE and compared against SAAMI MAP.
- Never recommends charge weights above published load data (v1 gives zero charge
  weight recommendations — only 'consult published load data').
"""
from __future__ import annotations

import csv
import io
import math
import os
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

VENDOR_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "vendor"))
if VENDOR_DIR not in sys.path and os.path.isdir(VENDOR_DIR):
    sys.path.insert(0, VENDOR_DIR)

import fitdecode  # noqa: E402

MPS_TO_FPS = 3.280839895
H2O_GRAINS_TO_CM3 = 0.06479891
GRAINS_TO_KG = 0.00006479891

# ---------------------------------------------------------------------------
# 1. Cartridge Reference Database
# Sources cited inline:
# - SAAMI Z299.4 Centerfire Rifle Standards (Maximum Average Pressure in PSI,
#   bullet diameter, standard COAL, and typical SAAMI test barrel length).
# - Gordon's Reloading Tool (GRT) & Brian's measured Water Capacity.xlsx /
#   calibrated .grtload files in /workspace/reloading_data for typical fired
#   case H2O capacity (grains H2O and cm³). Marked where values are typical
#   fired-case approximations vs SAAMI specification.
# ---------------------------------------------------------------------------
CARTRIDGES: Dict[str, Dict[str, Any]] = {
    ".223 Rem": {
        "name": ".223 Rem",
        "label": ".223 Remington / 5.56 NATO",
        # SAAMI Z299.4 .223 Rem MAP: 55,000 PSI piezo (CIP / 5.56 NATO is higher; we use conservative SAAMI .223 Rem 55k PSI)
        "saami_max_psi": 55000,
        "bullet_dia_in": 0.224,
        "case_h2o_gr": 31.06,  # Approx fired case H2O gr (Brian's 223_69gr_RMR_LT32_Calibrated.grtload = 2.0128 cm³)
        "case_vol_cm3": 2.013,
        "coal_in": 2.260,
        "case_len_in": 1.760,
        "default_barrel_in": 18.0,
        "saami_test_barrel_in": 24.0,
        "default_bullet_gr": 69,
        "common_bullets_gr": [55, 62, 69, 73, 75, 77, 80],
        # Reference velocity (fps) at ~52,000 PSI in a 24" barrel for 69gr bullet (Hodgdon/Sierra published max ~2950 fps)
        "ref_bullet_gr": 69.0,
        "ref_vel_24in_fps": 2950.0,
        "ref_psi": 52000.0,
        "fps_per_inch": 25.0,
        "candidate_powders": [
            {"name": "Vihtavuori N540", "notes": "Proven in Brian's 18\" AR (77gr TMK @ 2668-2670 fps, ES 9-11 fps)"},
            {"name": "Accurate LT-32", "notes": "Proven in Brian's 11.5\" & 18\" .223 (69gr RMR 3GH calibrated)"},
            {"name": "Accurate 2520 / 2460", "notes": "High case fill & low ES in 18\" .223 77gr node"},
            {"name": "Hodgdon Varget / H4895", "notes": "Classic temperature-stable extruded match powders for 69-77gr"},
        ],
        "source_note": "SAAMI Z299.4 (.223 Rem 55,000 PSI MAP, 0.224\" bore); H2O capacity 31.06 gr (2.013 cm³) from calibrated .grtload (approximation; varies by brass brand).",
    },
    ".308 Win": {
        "name": ".308 Win",
        "label": ".308 Winchester",
        # SAAMI Z299.4 .308 Win MAP: 62,000 PSI piezo
        "saami_max_psi": 62000,
        "bullet_dia_in": 0.308,
        "case_h2o_gr": 55.44,  # Brian's Water Capacity.xlsx 5-case mean (LC Match fired in Rem 700 = 55.436 gr / 3.592 cm³)
        "case_vol_cm3": 3.592,
        "coal_in": 2.800,
        "case_len_in": 2.015,
        "default_barrel_in": 22.0,
        "saami_test_barrel_in": 24.0,
        "default_bullet_gr": 168,
        "common_bullets_gr": [150, 155, 165, 168, 175, 178, 185],
        # Reference: 168gr in 24" barrel @ ~58,500 PSI -> ~2700 fps (calibrated from Rem 700 45.0gr N150 = 2647 fps @ 56,900 PSI in 22-24")
        "ref_bullet_gr": 168.0,
        "ref_vel_24in_fps": 2710.0,
        "ref_psi": 58500.0,
        "fps_per_inch": 22.0,
        "candidate_powders": [
            {"name": "Vihtavuori N150", "notes": "Proven in Brian's Rem 700 (168gr SMK @ 2647 fps, 0.333\" vert, R²=0.98)"},
            {"name": "Vihtavuori N540", "notes": "Proven in 22\" Criterion AR-10 & Rem 700 (168gr SMK @ ~2645 fps)"},
            {"name": "Hodgdon Varget / H4895", "notes": "Gold-standard temperature-insensitive extruded powders for 155-175gr"},
            {"name": "Shoot. World Match Rifle / LeverEvolution", "notes": "High velocity node in 22\" Criterion AR-10 (consult published data)"},
        ],
        "source_note": "SAAMI Z299.4 (.308 Win 62,000 PSI MAP, 0.308\" bore); H2O capacity 55.44 gr (3.592 cm³) from Brian's measured LC Match cases (approximation).",
    },
    "6.5 Creedmoor": {
        "name": "6.5 Creedmoor",
        "label": "6.5 Creedmoor",
        # SAAMI Z299.4 6.5 Creedmoor MAP: 62,000 PSI piezo
        "saami_max_psi": 62000,
        "bullet_dia_in": 0.264,
        "case_h2o_gr": 51.68,  # Brian's 24" T/C LRR Starline fired case mean = 51.684 gr (3.349 cm³); GRT default ~52.0 gr
        "case_vol_cm3": 3.349,
        "coal_in": 2.825,
        "case_len_in": 1.920,
        "default_barrel_in": 24.0,
        "saami_test_barrel_in": 24.0,
        "default_bullet_gr": 140,
        "common_bullets_gr": [120, 123, 130, 140, 143, 144, 145, 147],
        # Reference: 140gr in 24" barrel @ ~58,500 PSI -> ~2720 fps
        "ref_bullet_gr": 140.0,
        "ref_vel_24in_fps": 2720.0,
        "ref_psi": 58500.0,
        "fps_per_inch": 23.0,
        "candidate_powders": [
            {"name": "Vihtavuori N150", "notes": "Top performer in 24\" T/C LRR (140/144 SMK & 145 Barnes MB @ 2668-2712 fps)"},
            {"name": "Hodgdon H4350 / Varget", "notes": "Classic 6.5 CM match propellants (Varget & N550 excelled with 120-123gr)"},
            {"name": "Vihtavuori N550 / N555", "notes": "High linearity (R²>=0.985) and full burn in 22\"-24\" barrels"},
            {"name": "Hodgdon Hybrid 100V / SW Long Rifle", "notes": "Proven in 22\" Odin AR-10 gas-gun cycling & 200-yd ladder nodes"},
        ],
        "source_note": "SAAMI Z299.4 (6.5 Creedmoor 62,000 PSI MAP, 0.264\" bore); H2O capacity 51.68 gr (3.349 cm³) from Brian's Starline fired brass (approximation).",
    },
    "6.5 Grendel": {
        "name": "6.5 Grendel",
        "label": "6.5 Grendel",
        # SAAMI Z299.4 6.5 Grendel MAP: 52,000 PSI piezo
        "saami_max_psi": 52000,
        "bullet_dia_in": 0.264,
        "case_h2o_gr": 36.27,  # Brian's Water Capacity.xlsx Lapua/Starline/Hornady fired average = 36.265 gr (2.350 cm³)
        "case_vol_cm3": 2.350,
        "coal_in": 2.260,
        "case_len_in": 1.520,
        "default_barrel_in": 20.0,
        "saami_test_barrel_in": 24.0,
        "default_bullet_gr": 123,
        "common_bullets_gr": [90, 100, 105, 107, 120, 123, 130],
        # Reference: 123gr in 24" barrel @ ~50,000 PSI -> ~2580 fps (~2520 fps in 22" Howa, ~2470 fps in 20", ~2430 in 18")
        "ref_bullet_gr": 123.0,
        "ref_vel_24in_fps": 2580.0,
        "ref_psi": 49500.0,
        "fps_per_inch": 22.0,
        "candidate_powders": [
            {"name": "Shoot. World Match Rifle / AA2520", "notes": "Proven across 12\", 18\", 20\" & 22\" Grendel barrels (105-123gr)"},
            {"name": "Hodgdon LeverEvolution", "notes": "Top speed & tight groups in 18\" Faxon & 22\" Howa (120-130gr)"},
            {"name": "IMR 8208 XBR / Vihtavuori N133", "notes": "Sub-MOA & low ES in 22\" Howa Mini (100-130gr with CCI 400)"},
            {"name": "Vihtavuori N540 / Hodgdon H335", "notes": "Clean burn & flat velocity steps in 18\"-20\" AR-15 barrels"},
        ],
        "source_note": "SAAMI Z299.4 (6.5 Grendel 52,000 PSI MAP, 0.264\" bore); H2O capacity 36.27 gr (2.350 cm³) from Brian's Lapua/Starline/Hornady cases (approximation).",
    },
    "7mm PRC": {
        "name": "7mm PRC",
        "label": "7mm PRC (Precision Rifle Cartridge)",
        # SAAMI Public Introduction 7mm PRC (2022-06-16): 65,000 PSI MAP piezo
        "saami_max_psi": 65000,
        "bullet_dia_in": 0.284,
        "case_h2o_gr": 81.56,  # Brian's 7PRC_Barnes160_LRX_H4831SC_GarminInjected.grtload = 5.285 cm³ (81.56 gr H2O; Hornady Nickel = 82.11 gr)
        "case_vol_cm3": 5.285,
        "coal_in": 3.340,
        "case_len_in": 2.280,
        "default_barrel_in": 24.0,
        "saami_test_barrel_in": 24.0,
        "default_bullet_gr": 175,
        "common_bullets_gr": [160, 162, 168, 175, 180, 195, 200],
        # Reference: 175gr ELD-X in 24" barrel @ ~61,500 PSI -> ~2940 fps (Hornady Factory 175 ELD-X = 2938.8 fps in Brian's 24" X-Bolt; 160gr = ~3010 fps; 195gr = ~2815 fps)
        "ref_bullet_gr": 175.0,
        "ref_vel_24in_fps": 2945.0,
        "ref_psi": 61000.0,
        "fps_per_inch": 25.0,
        "candidate_powders": [
            {"name": "Vihtavuori N565", "notes": "Proven in 24\" Browning X-Bolt (195gr EOL @ 2776 & 2819 fps, 160gr CX ES 2.3 fps, R²=0.99)"},
            {"name": "Hodgdon H4831SC", "notes": "Proven sweet spot with 160gr Barnes LRX & Hornady CX (~3006 fps node)"},
            {"name": "Vihtavuori N560", "notes": "0.42 MOA at 200 yd with 175gr ELD-X (2915 fps) & 160gr CX (2949 fps)"},
            {"name": "Hodgdon H1000 / Vihtavuori N570", "notes": "Heavy-bullet (195gr Berger EOL) high-speed convergence @ ~2820 fps"},
        ],
        "source_note": "SAAMI 7mm PRC Spec (65,000 PSI MAP, 0.284\" bore); H2O capacity 81.56 gr (5.285 cm³) from Brian's calibrated 24\" X-Bolt .grtload (approximation).",
    },
    "300 BLK": {
        "name": "300 BLK",
        "label": "300 AAC Blackout",
        # SAAMI Z299.4 300 AAC Blackout MAP: 55,000 PSI piezo
        "saami_max_psi": 55000,
        "bullet_dia_in": 0.308,
        "case_h2o_gr": 24.45,  # Brian's 300 BLK - Hornady 190 SubX - V N110.grtload = 1.5843 cm³ (24.45 gr H2O)
        "case_vol_cm3": 1.584,
        "coal_in": 2.260,
        "case_len_in": 1.368,
        "default_barrel_in": 10.5,
        "saami_test_barrel_in": 16.0,
        "default_bullet_gr": 110,
        "common_bullets_gr": [110, 125, 150, 190, 200, 220],
        # Reference: 110gr in 16" barrel @ ~51,000 PSI -> ~2350 fps
        "ref_bullet_gr": 110.0,
        "ref_vel_24in_fps": 2470.0,
        "ref_psi": 51000.0,
        "fps_per_inch": 18.0,
        "candidate_powders": [
            {"name": "Vihtavuori N110", "notes": "Calibrated reference in Brian's 300 BLK .grtload (great for supersonic & heavy bullets)"},
            {"name": "Hodgdon H110 / Winchester 296", "notes": "Standard high-velocity supersonic powder for 110-125gr bullets"},
            {"name": "Hodgdon CFE BLK / Accurate 1680", "notes": "High gas volume for reliable AR cycling with 190-220gr subsonics"},
            {"name": "Hodgdon Lil'Gun", "notes": "Low charge weight & high efficiency in short 8\"-10.5\" barrels"},
        ],
        "source_note": "SAAMI Z299.4 (300 AAC Blackout 55,000 PSI MAP, 0.308\" bore); H2O capacity 24.45 gr (1.584 cm³) from Brian's Starline .grtload (approximation).",
    },
}

# ---------------------------------------------------------------------------
# 2. Chris Long Optimal Barrel Time (OBT) Nodes
# Source: Chris Long, "Shock Wave Theory and Barrel Harmonics (OBT)"
# Longitudinal acoustic wave speed in barrel steel c_steel ≈ 5,151 m/s (202,800 in/s).
# Standard published OBT nodes for a 24.0" reference barrel (in milliseconds),
# scaling linearly with barrel length L (in): OBT_n(L) = OBT_n(24") * (L / 24.0).
# Same table used in /workspace/reloading_data/deep_node_analysis.py.
# ---------------------------------------------------------------------------
OBT_24_NODES_MS: List[Tuple[str, float, str]] = [
    ("Node 3", 0.8999, "Fast / Light-Bullet Node"),
    ("Node 3.5 (Half)", 0.9862, "Half-Node (High Speed)"),
    ("Node 4", 1.0725, "High-Velocity Full Node"),
    ("Node 4.5 (Half)", 1.1481, "Upper Hunting / Match Half-Node"),
    ("Node 5", 1.2237, "Primary Accuracy Full Node (Most Popular)"),
    ("Node 5.5 (Half)", 1.2993, "Mild Half-Node"),
    ("Node 6", 1.3749, "Mild / Low-Pressure Full Node"),
    ("Node 6.5 (Half)", 1.4610, "Low-Velocity Half-Node"),
    ("Node 7", 1.5471, "Sub-Max / Reduced Load Full Node"),
]


def compute_obt_nodes(
    cartridge_name: str,
    bullet_weight_gr: float,
    barrel_length_in: float,
    measured_avg_fps: Optional[float] = None,
) -> Dict[str, Any]:
    """Compute Chris Long OBT barrel-time nodes and estimated target velocity windows.

    Formula & Approximation Disclosure:
    1. Barrel time node: t_node(L) = t_node(24") * (L / 24.0), from Chris Long's
       longitudinal acoustic shockwave model (c_steel ≈ 202,800 in/s).
    2. Internal ballistics velocity mapping (ESTIMATE):
       In a rifle barrel of effective bullet travel length L_eff = max(barrel_length - case_len*0.75, barrel_length*0.88),
       mean bullet velocity inside the bore is a fraction k_eff of muzzle velocity V0:
           t_barrel ≈ L_eff_ft / (k_eff * V0)   ==>   V0_est ≈ L_eff_ft / (k_eff * t_node)
       Because piezo pressure curve shape (rise time + expansion ratio) varies by cartridge
       expansion ratio and bullet sectional density, k_eff is approximately 0.56–0.61
       (calibrated against GRT OBT Node 5 reference points across Brian's 12 rifle barrels:
       e.g., 24" 6.5 CM 140gr Node 5 (1.2237 ms) -> ~2710 fps; 24" 7mm PRC 195gr Node 5 -> ~2776 fps;
       24" 7mm PRC 160gr Node 4.5 (1.1481 ms) -> ~3006 fps; 22" .308 Win 168gr Node 5 (1.1217 ms) -> ~2645 fps).
    """
    spec = CARTRIDGES.get(cartridge_name, CARTRIDGES["6.5 Creedmoor"])
    b_len = max(6.0, min(36.0, float(barrel_length_in)))
    b_wt = max(20.0, min(400.0, float(bullet_weight_gr)))

    # Reference velocity at Node 5 for this cartridge in a 24" barrel, adjusted for bullet weight
    # Using Powley-style mass scaling: V ~ (m_ref / m_bullet)^0.42
    mass_ratio = (spec["ref_bullet_gr"] / b_wt) ** 0.42
    # Barrel length velocity adjustment relative to SAAMI reference barrel
    len_diff = b_len - spec["saami_test_barrel_in"]
    v_ref_node5_at_L = (spec["ref_vel_24in_fps"] * mass_ratio + len_diff * spec["fps_per_inch"]) * 0.985

    # Node 5 time at barrel length L:
    t_node5_ms = 1.2237 * (b_len / 24.0)
    # Effective proportionality constant (fps * ms) so V(t) = C_obt / (t_ms ^ 0.82)
    # In internal ballistics (QuickLOAD/GRT), barrel time varies as ~ V^(-1.15 to -1.25), so V ~ t^(-0.82)
    c_obt = v_ref_node5_at_L * (t_node5_ms ** 0.82)

    nodes_out = []
    closest_node = None
    min_diff = 1e9

    for node_label, t24_ms, desc in OBT_24_NODES_MS:
        t_ms = round(t24_ms * (b_len / 24.0), 4)
        v_center = round(c_obt / (t_ms ** 0.82), 0)
        # +/- 12 fps window (~0.4% velocity flat spot)
        v_low = int(v_center - 12)
        v_high = int(v_center + 12)
        is_full = "Half" not in node_label
        delta_fps = round(measured_avg_fps - v_center, 1) if measured_avg_fps else None
        entry = {
            "node": node_label,
            "is_full_node": is_full,
            "time_ms": t_ms,
            "target_fps": int(v_center),
            "window_fps": f"{v_low} – {v_high} fps",
            "window_low": v_low,
            "window_high": v_high,
            "description": desc,
            "delta_from_measured_fps": delta_fps,
        }
        nodes_out.append(entry)
        if measured_avg_fps is not None and abs(measured_avg_fps - v_center) < min_diff:
            min_diff = abs(measured_avg_fps - v_center)
            closest_node = entry

    return {
        "formula_used": (
            "Chris Long OBT Longitudinal Acoustic Wave Formula: "
            "t_node(L) = t_node(24\") × (L_in / 24.0) with c_steel ≈ 5,151 m/s (202,800 in/s). "
            "Target velocity window is an ESTIMATE mapped via internal-ballistics bore-time scaling "
            "V_node ≈ V_ref(Node 5, L, bullet_wt) × (t_Node5 / t_node)^0.82 (±12 fps window)."
        ),
        "is_estimate": True,
        "nodes": nodes_out,
        "closest_node": closest_node,
    }


# ---------------------------------------------------------------------------
# 3. Simple Pressure Estimate Gauge (Clearly labeled ESTIMATE vs SAAMI Max)
# ---------------------------------------------------------------------------
def estimate_pressure(
    cartridge_name: str,
    bullet_weight_gr: float,
    barrel_length_in: float,
    measured_avg_fps: float,
    measured_max_fps: Optional[float] = None,
    case_h2o_gr: Optional[float] = None,
) -> Dict[str, Any]:
    """Estimate peak chamber pressure (PSI) from measured muzzle velocity, barrel length, and bullet weight.

    APPROXIMATION & SAFETY NOTE:
    True peak chamber pressure depends on powder burn rate (vivacity), seating depth, bore friction,
    primer, and ambient temperature. Without a piezo transducer, this uses a Powley / kinetic-energy
    internal ballistics scaling law anchored to published SAAMI / Hodgdon / Vihtavuori reference velocities:
        P_est ≈ P_ref × (V_measured / V_expected_at_P_ref)^2.35 × (H2O_default / H2O_actual)^1.4
    Always cross-check against published powder-manufacturer load manuals.
    """
    spec = CARTRIDGES.get(cartridge_name, CARTRIDGES["6.5 Creedmoor"])
    saami_max = spec["saami_max_psi"]
    b_len = max(6.0, min(36.0, float(barrel_length_in)))
    b_wt = max(20.0, min(400.0, float(bullet_weight_gr)))
    h2o = float(case_h2o_gr) if (case_h2o_gr and case_h2o_gr > 5) else spec["case_h2o_gr"]

    # Expected velocity at reference pressure (spec["ref_psi"]) for this barrel length and bullet weight
    mass_factor = (spec["ref_bullet_gr"] / b_wt) ** 0.42
    len_adj = (b_len - spec["saami_test_barrel_in"]) * spec["fps_per_inch"]
    v_ref = spec["ref_vel_24in_fps"] * mass_factor + len_adj

    # Use avg velocity for nominal estimate, and max shot velocity for peak shot estimate
    v_nom = max(400.0, float(measured_avg_fps))
    v_pk = max(v_nom, float(measured_max_fps)) if measured_max_fps else v_nom

    vol_factor = (spec["case_h2o_gr"] / h2o) ** 1.4
    est_avg_psi = int(round(spec["ref_psi"] * ((v_nom / v_ref) ** 2.35) * vol_factor, -2))
    est_max_psi = int(round(spec["ref_psi"] * ((v_pk / v_ref) ** 2.35) * vol_factor, -2))

    est_avg_psi = max(15000, min(85000, est_avg_psi))
    est_max_psi = max(15000, min(85000, est_max_psi))

    pct_saami = round((est_max_psi / saami_max) * 100.0, 1)
    margin_psi = saami_max - est_max_psi

    if est_max_psi >= saami_max or pct_saami >= 99.0:
        status = "RED — NEAR / OVER SAAMI MAX ESTIMATE"
        color = "red"
        advice = (
            "ESTIMATED peak pressure meets or exceeds the SAAMI Maximum Average Pressure ceiling. "
            "STOP and verify against published load manuals; inspect brass for ejector marks, heavy bolt lift, or flat primers."
        )
    elif pct_saami >= 92.0:
        status = "YELLOW — UPPER OPERATING WINDOW (APPROACHING MAX)"
        color = "yellow"
        advice = (
            "ESTIMATED pressure is in the upper 92%–98% window of SAAMI Max. Typical of full-power factory ammo or top accuracy nodes, "
            "but leave a safety margin for hot weather and always consult published load data."
        )
    else:
        status = "GREEN — WITHIN NORMAL SAAMI OPERATING ESTIMATE"
        color = "green"
        advice = (
            "ESTIMATED pressure is comfortably below the SAAMI Max PSI ceiling based on velocity-to-barrel-length scaling. "
            "Remember that fast-burning powders can still spike peak pressure at low velocities — always verify in a published load manual."
        )

    speed_offset_fps = round(v_nom - v_ref, 1)

    return {
        "is_estimate": True,
        "label": "ESTIMATE ONLY (Velocity-Derived Internal Ballistics Approximation — Not a Piezo Measurement)",
        "estimated_avg_psi": est_avg_psi,
        "estimated_peak_shot_psi": est_max_psi,
        "saami_max_psi": saami_max,
        "percent_of_saami_max": pct_saami,
        "margin_below_saami_psi": margin_psi,
        "reference_expected_fps": round(v_ref, 1),
        "barrel_speed_offset_fps": speed_offset_fps,
        "status": status,
        "color": color,
        "advice": advice,
        "disclaimer": (
            "SAFETY WARNING & DISCLAIMER: This pressure value is a mathematical ESTIMATE inferred from muzzle velocity, "
            "barrel length, bullet weight, and case capacity. It is NOT a direct chamber pressure measurement. "
            "Fast powders, deep bullet seating (jam into lands), tight bores, or high temperatures can create dangerous pressures "
            "even at normal velocities. This tool NEVER recommends powder charge weights. Always consult official published load data "
            "(Hodgdon, Vihtavuori, Alliant, Western, Hornady, Sierra, Barnes, Berger) and never exceed published maximum charges."
        ),
    }


# ---------------------------------------------------------------------------
# 4. Chrono File Parsers: Garmin Xero .fit (via fitdecode) + Generic CSV
# Strictly NO standard deviation anywhere.
# ---------------------------------------------------------------------------
LOCAL_TZ_NAME = os.environ.get("NODEFINDER_TZ", "America/Los_Angeles")


def _to_local(ts: Any) -> Any:
    """FIT timestamps are UTC. Convert to the shooter's zone (NODEFINDER_TZ, default Pacific)."""
    try:
        from zoneinfo import ZoneInfo
        if getattr(ts, "tzinfo", None) is None:
            from datetime import timezone
            ts = ts.replace(tzinfo=timezone.utc)
        return ts.astimezone(ZoneInfo(LOCAL_TZ_NAME))
    except Exception:
        return ts


def parse_fit_bytes(data: bytes, filename: str = "upload.fit") -> Dict[str, Any]:
    """Decode a Garmin Xero C1 Pro binary .fit file into session metadata and shots.
    Mirrors Brian's decode_fit() in reloading_sync_tool.py, with SD completely omitted.
    """
    sess: Dict[str, Any] = {}
    shots: List[Dict[str, Any]] = []
    bio = io.BytesIO(data)
    with fitdecode.FitReader(bio, error_handling=fitdecode.ErrorHandling.IGNORE) as fit:
        for frame in fit:
            if isinstance(frame, fitdecode.FitDataMessage):
                d = {f.name: f.value for f in frame.fields if f.value is not None}
                if frame.name == "chrono_shot_session":
                    sess = d
                elif frame.name == "chrono_shot_data":
                    shots.append(d)

    fps_list: List[float] = []
    shot_rows: List[Dict[str, Any]] = []
    prev_ts = None

    for idx, s in enumerate(shots, 1):
        raw_spd = s.get("shot_speed")
        if raw_spd is None:
            continue
        fps = round(float(raw_spd) * MPS_TO_FPS, 1)
        mps = round(float(raw_spd), 3)
        ts = s.get("timestamp")
        gap_s = round((ts - prev_ts).total_seconds(), 1) if (ts and prev_ts) else 0.0
        prev_ts = ts or prev_ts
        fps_list.append(fps)
        shot_rows.append({
            "shot_num": idx,
            "velocity_fps": fps,
            "velocity_mps": mps,
            "charge_gr": None,
            "gap_sec": gap_s,
            "cooling_pause": gap_s >= 180.0,
            "timestamp": _to_local(ts).strftime("%H:%M:%S") if hasattr(ts, "strftime") else "",
            "notes": "Cooling Pause (>3 min)" if gap_s >= 180.0 else "",
        })

    if not fps_list:
        raise ValueError(f"No valid chronograph shot velocities found in FIT file '{filename}'.")

    fn = os.path.basename(filename)
    stem = os.path.splitext(fn)[0]
    dt_str = stem
    m = re.search(r"(\d{2}-\d{2}-\d{4}_\d{2}-\d{2}-\d{2})", stem)
    if m:
        try:
            dt_obj = datetime.strptime(m.group(1), "%m-%d-%Y_%H-%M-%S")
            dt_str = dt_obj.strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            pass

    # Filenames have been seen up to 2 h off from the shot clock (e.g. 07-11-2026_14-52 file, first shot 12:52 PDT),
    # so prefer the per-shot UTC timestamps converted to local time.
    shot_ts = [s.get("timestamp") for s in shots if hasattr(s.get("timestamp"), "strftime")]
    session_start = session_end = session_mid = None
    if shot_ts:
        a, b = _to_local(min(shot_ts)), _to_local(max(shot_ts))
        session_start, session_end = a.strftime("%Y-%m-%d %H:%M"), b.strftime("%Y-%m-%d %H:%M")
        session_mid = (a + (b - a) / 2).strftime("%Y-%m-%d %H:%M")
        dt_str = a.strftime("%Y-%m-%d %H:%M:%S")

    avg_fps = round(sum(fps_list) / len(fps_list), 1)
    min_fps = round(min(fps_list), 1)
    max_fps = round(max(fps_list), 1)
    es_fps = round(max_fps - min_fps, 1)

    return {
        "source_type": "Garmin Xero .FIT",
        "filename": fn,
        "session_datetime": dt_str,
        "session_start_local": session_start,
        "session_end_local": session_end,
        "session_mid_local": session_mid,
        "local_tz": LOCAL_TZ_NAME,
        "garmin_grain_weight": sess.get("grain_weight"),
        "projectile_type": sess.get("projectile_type"),
        "shot_count": len(fps_list),
        "avg_fps": avg_fps,
        "min_fps": min_fps,
        "max_fps": max_fps,
        "es_fps": es_fps,
        "shots": shot_rows,
    }


def parse_csv_text(text: str, filename: str = "upload.csv") -> Dict[str, Any]:
    """Parse generic chronograph CSV files (Garmin CSV, LabRadar, MagnetoSpeed, ProChrono, or simple table).
    Automatically detects velocity columns (fps or m/s) and optional charge weight columns.
    Ignores summary rows (Min, Max, Avg, ES, etc.) and never extracts or computes SD.
    """
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    reader = list(csv.reader(lines))
    if not reader:
        raise ValueError("Uploaded CSV file is empty.")

    shot_rows: List[Dict[str, Any]] = []
    fps_list: List[float] = []
    detected_bwt: Optional[float] = None

    vel_col: Optional[int] = None
    chg_col: Optional[int] = None
    bwt_col: Optional[int] = None
    note_col: Optional[int] = None
    unit_is_mps = False

    summary_prefixes = (
        "series,", "min", "max", "avg", "average", "es", "extreme", "s-d", "sd", "std", "----", "date,", "time,"
    )

    for row in reader:
        if not row:
            continue
        joined_low = ",".join(c.strip().lower() for c in row)
        if not joined_low or joined_low.startswith("----"):
            continue

        # Check if this row is a header row
        cells_low = [c.strip().lower() for c in row]
        if any(k in c for c in cells_low for k in ("velocity", "speed", "vel (fps)", "fps", "v0")):
            for idx, c in enumerate(cells_low):
                if any(k in c for k in ("velocity", "speed", "fps", "v0")):
                    vel_col = idx
                    if "m/s" in c or "mps" in c:
                        unit_is_mps = True
                elif any(k in c for k in ("charge", "grains", "powder wt", "chg")):
                    chg_col = idx
                elif any(k in c for k in ("bullet weight", "grain weight", "proj")):
                    bwt_col = idx
                elif any(k in c for k in ("note", "comment", "shot list")):
                    note_col = idx
            continue

        # Skip summary stats lines (like MagnetoSpeed Min/Max/Avg/ES headers)
        first_cell = cells_low[0] if cells_low else ""
        if first_cell in ("min", "max", "avg", "average", "es", "s-d", "sd", "series") and (
            len(cells_low) < 2 or not re.match(r"^\d+$", cells_low[1])
        ):
            continue

        # Extract velocity from vel_col or fallback scan
        vel_val: Optional[float] = None
        chg_val: Optional[float] = None
        note_str = ""

        if vel_col is not None and vel_col < len(row):
            raw_v = re.sub(r"[^\d.\-]", "", row[vel_col])
            if raw_v:
                try:
                    vel_val = float(raw_v)
                except ValueError:
                    vel_val = None

        if vel_val is None:
            # Heuristic for headerless or MagnetoSpeed rows like: "1, 1, 2831, ft/s"
            for idx, cell in enumerate(row):
                c_clean = re.sub(r"[^\d.\-]", "", cell)
                if not c_clean:
                    continue
                try:
                    v_cand = float(c_clean)
                    if 400.0 <= v_cand <= 4600.0 and idx >= 1:
                        vel_val = v_cand
                        break
                except ValueError:
                    pass

        if vel_val is None or vel_val < 300.0 or vel_val > 5000.0:
            continue

        if unit_is_mps or (vel_val < 1350.0 and any("m/s" in c.lower() for c in row)):
            fps = round(vel_val * MPS_TO_FPS, 1)
            mps = round(vel_val, 3)
        else:
            fps = round(vel_val, 1)
            mps = round(vel_val / MPS_TO_FPS, 3)

        if chg_col is not None and chg_col < len(row):
            raw_c = re.sub(r"[^\d.\-]", "", row[chg_col])
            if raw_c:
                try:
                    chg_val = float(raw_c)
                except ValueError:
                    chg_val = None

        if bwt_col is not None and bwt_col < len(row) and detected_bwt is None:
            raw_b = re.sub(r"[^\d.\-]", "", row[bwt_col])
            if raw_b:
                try:
                    detected_bwt = float(raw_b)
                except ValueError:
                    pass

        if note_col is not None and note_col < len(row):
            note_str = row[note_col].strip()
            # In ProChrono CSV, Shot List often has charge like "223 n140 24.5"
            if chg_val is None and note_str:
                m_chg = re.search(r"(\d{2}\.\d+|\d{2})\s*(?:gr)?$", note_str)
                if m_chg:
                    try:
                        cand_c = float(m_chg.group(1))
                        if 10.0 <= cand_c <= 110.0:
                            chg_val = cand_c
                    except ValueError:
                        pass

        fps_list.append(fps)
        shot_rows.append({
            "shot_num": len(fps_list),
            "velocity_fps": fps,
            "velocity_mps": mps,
            "charge_gr": chg_val,
            "gap_sec": 0.0,
            "cooling_pause": False,
            "timestamp": "",
            "notes": note_str,
        })

    if not fps_list:
        raise ValueError(f"Could not find valid shot velocities (fps) in CSV '{filename}'.")

    # Filenames have been seen up to 2 h off from the shot clock (e.g. 07-11-2026_14-52 file, first shot 12:52 PDT),
    # so prefer the per-shot UTC timestamps converted to local time.
    shot_ts: List[Any] = []  # CSV exports carry no reliable per-shot UTC timestamps
    session_start = session_end = session_mid = None
    if shot_ts:
        a, b = _to_local(min(shot_ts)), _to_local(max(shot_ts))
        session_start, session_end = a.strftime("%Y-%m-%d %H:%M"), b.strftime("%Y-%m-%d %H:%M")
        session_mid = (a + (b - a) / 2).strftime("%Y-%m-%d %H:%M")
        dt_str = a.strftime("%Y-%m-%d %H:%M:%S")

    avg_fps = round(sum(fps_list) / len(fps_list), 1)
    min_fps = round(min(fps_list), 1)
    max_fps = round(max(fps_list), 1)
    es_fps = round(max_fps - min_fps, 1)

    return {
        "source_type": "Chronograph CSV",
        "filename": os.path.basename(filename),
        "session_datetime": "From CSV",
        "garmin_grain_weight": detected_bwt,
        "projectile_type": None,
        "shot_count": len(fps_list),
        "avg_fps": avg_fps,
        "min_fps": min_fps,
        "max_fps": max_fps,
        "es_fps": es_fps,
        "shots": shot_rows,
    }


# ---------------------------------------------------------------------------
# 5. Handload Charge Assignment & Linear Fit (Velocity vs Charge: R² & RMSE)
# ---------------------------------------------------------------------------
def parse_charge_list(
    charge_input: str,
    start_charge: Optional[float],
    step_charge: Optional[float],
    shot_count: int,
) -> List[Optional[float]]:
    """Build per-shot charge weights from either a comma/space list or start+step ladder."""
    if charge_input and charge_input.strip():
        parts = re.findall(r"\d+(?:\.\d+)?", charge_input)
        vals = [round(float(x), 2) for x in parts]
        if vals:
            if len(vals) == shot_count:
                return vals
            # If user entered N group charges and shot_count is a multiple (e.g. 3 shots per charge)
            if len(vals) > 1 and shot_count % len(vals) == 0:
                reps = shot_count // len(vals)
                expanded = []
                for v in vals:
                    expanded.extend([v] * reps)
                return expanded
            # Otherwise pad or truncate
            out: List[Optional[float]] = []
            for i in range(shot_count):
                out.append(vals[i] if i < len(vals) else vals[-1])
            return out

    if start_charge is not None and start_charge > 0:
        step = float(step_charge) if (step_charge is not None) else 0.0
        return [round(float(start_charge) + i * step, 2) for i in range(shot_count)]

    return [None] * shot_count


def compute_ladder_fit(shots: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Compute Ordinary Least Squares linear regression of Velocity (fps) vs Charge (gr),
    returning slope (fps/gr), intercept, R², RMSE (fps), per-shot residuals, and flat-spot steps.
    """
    pairs = [
        (float(s["charge_gr"]), float(s["velocity_fps"]), int(s["shot_num"]))
        for s in shots
        if s.get("charge_gr") is not None and s.get("velocity_fps") is not None
    ]
    if len(pairs) < 2:
        return None

    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]
    if max(xs) - min(xs) < 1e-6:
        # All shots at the same single charge weight (group test, not a multi-charge ladder)
        return None

    n = len(pairs)
    mean_x = sum(xs) / n
    mean_y = sum(ys) / n
    ss_xx = sum((x - mean_x) ** 2 for x in xs)
    ss_yy = sum((y - mean_y) ** 2 for y in ys)
    ss_xy = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys))

    slope = ss_xy / ss_xx if ss_xx > 0 else 0.0
    intercept = mean_y - slope * mean_x

    residuals = []
    ss_res = 0.0
    for x, y, snum in pairs:
        y_hat = slope * x + intercept
        res = y - y_hat
        ss_res += res ** 2
        residuals.append({
            "shot_num": snum,
            "charge_gr": round(x, 2),
            "velocity_fps": round(y, 1),
            "predicted_fps": round(y_hat, 1),
            "residual_fps": round(res, 1),
        })

    r_squared = 1.0 - (ss_res / ss_yy) if ss_yy > 0 else 1.0
    r_squared = max(0.0, min(1.0, r_squared))
    rmse_fps = math.sqrt(ss_res / n)

    # Identify adjacent charge steps with smallest velocity jump ("flat spots")
    sorted_pairs = sorted(pairs, key=lambda t: t[0])
    step_spans = []
    for i in range(len(sorted_pairs) - 1):
        c1, v1, _ = sorted_pairs[i]
        c2, v2, _ = sorted_pairs[i + 1]
        if c2 > c1:
            step_spans.append({
                "charge_window": f"{c1:.2f} – {c2:.2f} gr",
                "vel_window": f"{v1:.1f} – {v2:.1f} fps",
                "avg_vel_fps": round((v1 + v2) / 2.0, 1),
                "vel_delta_fps": round(v2 - v1, 1),
            })

    if r_squared >= 0.96 and rmse_fps <= 12.0:
        verdict = "EXCELLENT LINEAR COMBUSTION (R² >= 0.96, low RMSE — smooth, predictable pressure/velocity climb)"
    elif r_squared >= 0.90:
        verdict = "GOOD LINEARITY (R² >= 0.90 — usable climb with minor step-to-step variance)"
    else:
        verdict = "ERRATIC / NON-LINEAR LADDER (R² < 0.90 — watch for erratic ignition, low case fill, or pressure spikes)"

    return {
        "point_count": n,
        "charge_min_gr": round(min(xs), 2),
        "charge_max_gr": round(max(xs), 2),
        "slope_fps_per_gr": round(slope, 2),
        "intercept_fps": round(intercept, 1),
        "r_squared": round(r_squared, 4),
        "rmse_fps": round(rmse_fps, 2),
        "verdict": verdict,
        "points": residuals,
        "step_spans": step_spans,
    }


# ---------------------------------------------------------------------------
# 6. Optional .grtload XML Companion Export
# ---------------------------------------------------------------------------
def build_grtload_xml(analysis: Dict[str, Any]) -> str:
    """Build a clean, valid Gordon's Reloading Tool (.grtload) XML string containing
    the cartridge specifications and the <appendix><Measurement> block with all shots.
    """
    cart_name = analysis["inputs"]["cartridge"]
    spec = CARTRIDGES.get(cart_name, CARTRIDGES["6.5 Creedmoor"])
    b_wt = analysis["inputs"]["bullet_weight_gr"]
    b_len_mm = round(analysis["inputs"]["barrel_length_in"] * 25.4, 3)
    powder_name = analysis["inputs"].get("powder_name") or "Calibrated_Powder"
    shots = analysis["chrono"]["shots"]

    root = ET.Element("GordonsReloadingTool", attrib={"version": "2021.2030-NIGHTLY"})
    inner = ET.SubElement(root, "InnerBallistikInput")
    title_el = ET.SubElement(inner, "title")
    title_el.text = urllib.parse.quote(f"{cart_name} {b_wt}gr - Nodie Export")

    cal = ET.SubElement(inner, "caliber")
    ET.SubElement(cal, "input", name="CaliberName", value=urllib.parse.quote(cart_name), unit="", type="string")
    ET.SubElement(cal, "input", name="oal", value=str(round(spec["coal_in"] * 25.4, 3)), unit="mm", type="decimal")
    ET.SubElement(cal, "input", name="caselen", value=str(round(spec["case_len_in"] * 25.4, 3)), unit="mm", type="decimal")
    ET.SubElement(cal, "input", name="casevol", value=str(spec["case_vol_cm3"]), unit="cm3", type="decimal")
    ET.SubElement(cal, "input", name="Dz", value=str(round(spec["bullet_dia_in"] * 25.4, 4)), unit="mm", type="decimal")
    ET.SubElement(cal, "input", name="pMaxZul", value=str(round(spec["saami_max_psi"] * 0.06894757, 2)), unit="bar", type="decimal")

    gun = ET.SubElement(inner, "gun")
    ET.SubElement(gun, "input", name="xe", value=str(b_len_mm), unit="mm", type="decimal", descr="barrel length")

    proj = ET.SubElement(inner, "projectile")
    ET.SubElement(proj, "input", name="Dbul", value=str(round(spec["bullet_dia_in"] * 25.4, 4)), unit="mm", type="decimal")
    ET.SubElement(proj, "input", name="mp", value=str(round(b_wt * 0.06479891, 5)), unit="g", type="decimal")

    prop = ET.SubElement(inner, "propellant")
    ET.SubElement(prop, "input", name="pname", value=urllib.parse.quote(str(powder_name)), unit="", type="string")

    appendix = ET.SubElement(inner, "appendix")
    meas = ET.SubElement(
        appendix,
        "Measurement",
        attrib={
            "index": "1",
            "showinreport": "true",
            "title": urllib.parse.quote(f"NodeFinder_{analysis['chrono']['filename']}"),
        },
    )

    # Group shots by charge_gr (or default single group)
    by_chg: Dict[float, List[Dict[str, Any]]] = {}
    for s in shots:
        c_val = float(s["charge_gr"]) if s.get("charge_gr") is not None else 0.0
        by_chg.setdefault(c_val, []).append(s)

    for chg_gr, s_list in by_chg.items():
        kg_val = round(chg_gr * GRAINS_TO_KG, 12)
        chg_label = f"{chg_gr:.2f}gr" if chg_gr > 0 else "Factory_or_Unassigned"
        chg_el = ET.SubElement(
            meas,
            "charge",
            attrib={
                "name": urllib.parse.quote(chg_label),
                "showinreport": "true",
                "expanded": "true",
                "expandedstats": "true",
                "note": urllib.parse.quote(f"Imported from {analysis['chrono']['filename']}"),
                "value": f"{kg_val:.12f}",
                "menu": "",
                "menuvalue": "",
                "menuunit": "m",
                "source": "",
                "sourceoptions": "%7B%7D",
            },
        )
        for idx_s, s in enumerate(s_list, 1):
            ET.SubElement(
                chg_el,
                "shot",
                attrib={
                    "name": urllib.parse.quote(f"Shot {idx_s}"),
                    "velocity": f"{s['velocity_mps']:.6f}",
                    "pressure": "0",
                },
            )

    xml_bytes = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    return xml_bytes.decode("utf-8")


# ---------------------------------------------------------------------------
# 7. Top-Level Analysis Orchestrator
# ---------------------------------------------------------------------------
def estimate_psi_at_velocity(
    cartridge_name: str, bullet_weight_gr: float, barrel_length_in: float,
    velocity_fps: float, case_h2o_gr: Optional[float] = None,
) -> int:
    """Same velocity-scaling ESTIMATE as estimate_pressure(), evaluated at one velocity."""
    spec = CARTRIDGES.get(cartridge_name, CARTRIDGES["6.5 Creedmoor"])
    b_len = max(6.0, min(36.0, float(barrel_length_in)))
    b_wt = max(20.0, min(400.0, float(bullet_weight_gr)))
    h2o = float(case_h2o_gr) if (case_h2o_gr and case_h2o_gr > 5) else spec["case_h2o_gr"]
    v_ref = spec["ref_vel_24in_fps"] * (spec["ref_bullet_gr"] / b_wt) ** 0.42 + (
        b_len - spec["saami_test_barrel_in"]) * spec["fps_per_inch"]
    vol_factor = (spec["case_h2o_gr"] / h2o) ** 1.4
    v = max(400.0, float(velocity_fps))
    return int(round(spec["ref_psi"] * ((v / v_ref) ** 2.35) * vol_factor, -2))


def apply_pressure_limit(
    obt: Dict[str, Any], cartridge_name: str, bullet_weight_gr: float,
    barrel_length_in: float, case_h2o_gr: Optional[float],
    measured_avg_fps: Optional[float], max_psi: Optional[float] = None,
) -> Dict[str, Any]:
    """Flag OBT nodes whose ESTIMATED pressure exceeds the limit (default SAAMI MAP).

    Over-limit nodes stay in the list (greyed out in the UI) but are never
    chosen as the recommended/closest node.
    """
    spec = CARTRIDGES.get(cartridge_name, CARTRIDGES["6.5 Creedmoor"])
    source = "user-entered limit"
    limit = float(max_psi) if (max_psi and float(max_psi) > 0) else None
    if limit is None:
        limit, source = float(spec["saami_max_psi"]), "SAAMI MAP"
    limit = min(limit, float(spec["saami_max_psi"])) if source != "SAAMI MAP" and limit > spec["saami_max_psi"] else limit
    over = 0
    for n in obt["nodes"]:
        psi = estimate_psi_at_velocity(cartridge_name, bullet_weight_gr, barrel_length_in, n["target_fps"], case_h2o_gr)
        n["est_psi"] = psi
        n["over_limit"] = psi > limit
        over += n["over_limit"]
    ok = [n for n in obt["nodes"] if not n["over_limit"]]
    if measured_avg_fps is not None and ok:
        obt["closest_node"] = min(ok, key=lambda n: abs(measured_avg_fps - n["target_fps"]))
    elif not ok:
        obt["closest_node"] = None
    return {"max_psi": int(limit), "source": source, "over_limit_count": over,
            "note": "Nodes whose ESTIMATED pressure exceeds the limit are greyed out and never recommended. "
                    "User limits above SAAMI MAP are capped at SAAMI MAP."}


def analyze_session(
    cartridge: str,
    bullet_weight_gr: float,
    barrel_length_in: float,
    file_bytes: bytes,
    filename: str,
    ammo_type: str = "factory",  # "factory" or "handload"
    factory_label: str = "",
    powder_name: str = "",
    charges_text: str = "",
    start_charge_gr: Optional[float] = None,
    step_charge_gr: Optional[float] = None,
    case_h2o_override_gr: Optional[float] = None,
    max_psi: Optional[float] = None,
    session_temp_f: Optional[float] = None,
    shoot_temp_f: Optional[float] = None,
    barrel_contour: Optional[str] = None,
    coal_in: Optional[float] = None,
    temp_coef_fps_per_f: Optional[float] = None,
    daily_lo_pct: Optional[float] = None,
    daily_hi_pct: Optional[float] = None,
    hunting_max_pct: Optional[float] = None,
    where_when: str = "",
) -> Dict[str, Any]:
    """Run full deterministic analysis on an uploaded .fit or .csv chronograph file."""
    if cartridge not in CARTRIDGES:
        raise ValueError(f"Unsupported cartridge '{cartridge}'. Choose from: {', '.join(CARTRIDGES.keys())}")

    spec = CARTRIDGES[cartridge]
    ext = os.path.splitext(filename.lower())[1]
    if ext == ".fit":
        chrono = parse_fit_bytes(file_bytes, filename=filename)
    else:
        text = file_bytes.decode("utf-8", errors="replace")
        chrono = parse_csv_text(text, filename=filename)

    # If user didn't override bullet weight or left it 0, fall back to FIT grain_weight or cartridge default
    b_wt = float(bullet_weight_gr) if (bullet_weight_gr and float(bullet_weight_gr) > 0) else (
        float(chrono["garmin_grain_weight"]) if chrono.get("garmin_grain_weight") else float(spec["default_bullet_gr"])
    )
    b_len = float(barrel_length_in) if (barrel_length_in and float(barrel_length_in) > 0) else float(spec["default_barrel_in"])
    h2o_gr = float(case_h2o_override_gr) if (case_h2o_override_gr and float(case_h2o_override_gr) > 0) else spec["case_h2o_gr"]

    # Assign handload charges if provided
    if ammo_type.lower() == "handload":
        assigned_charges = parse_charge_list(
            charges_text, start_charge_gr, step_charge_gr, chrono["shot_count"]
        )
        for s, chg in zip(chrono["shots"], assigned_charges):
            if chg is not None:
                s["charge_gr"] = chg

    obt = compute_obt_nodes(
        cartridge_name=cartridge,
        bullet_weight_gr=b_wt,
        barrel_length_in=b_len,
        measured_avg_fps=chrono["avg_fps"],
    )

    # Annotate each shot with nearest OBT node if within ±18 fps
    for s in chrono["shots"]:
        v = s["velocity_fps"]
        near = None
        for n in obt["nodes"]:
            if abs(v - n["target_fps"]) <= 18.0:
                near = f"{n['node']} ({n['target_fps']} fps)"
                break
        s["near_obt_node"] = near or ""

    pressure = estimate_pressure(
        cartridge_name=cartridge,
        bullet_weight_gr=b_wt,
        barrel_length_in=b_len,
        measured_avg_fps=chrono["avg_fps"],
        measured_max_fps=chrono["max_fps"],
        case_h2o_gr=h2o_gr,
    )

    pressure_limit = apply_pressure_limit(
        obt, cartridge, b_wt, b_len, h2o_gr, chrono["avg_fps"], max_psi
    )
    for s in chrono["shots"]:
        if s.get("near_obt_node"):
            lbl = s["near_obt_node"].split(" (")[0]
            if any(n["node"] == lbl and n["over_limit"] for n in obt["nodes"]):
                s["near_obt_node"] += " — OVER PRESSURE LIMIT"

    ladder_fit = compute_ladder_fit(chrono["shots"]) if ammo_type.lower() == "handload" else None

    result = {
        "inputs": {
            "cartridge": cartridge,
            "cartridge_label": spec["label"],
            "bullet_weight_gr": b_wt,
            "bullet_dia_in": spec["bullet_dia_in"],
            "barrel_length_in": b_len,
            "case_h2o_gr": round(h2o_gr, 2),
            "case_vol_cm3": round(h2o_gr * H2O_GRAINS_TO_CM3, 3),
            "saami_max_psi": spec["saami_max_psi"],
            "coal_in": spec["coal_in"],
            "source_note": spec["source_note"],
            "ammo_type": "Handloads" if ammo_type.lower() == "handload" else "Factory Ammo",
            "factory_label": factory_label.strip(),
            "powder_name": powder_name.strip(),
        },
        "chrono": chrono,
        "obt": obt,
        "pressure": pressure,
        "pressure_limit": pressure_limit,
        "ladder_fit": ladder_fit,
        "candidate_powders": spec["candidate_powders"],
        "charge_recommendation_policy": (
            "NO CHARGE WEIGHT RECOMMENDATIONS IN V1: Always consult official published load data "
            "(Hodgdon, Vihtavuori, Alliant, Western, Hornady, Sierra, Barnes, Berger) and never exceed published maximums."
        ),
    }
    from .targets import compute_velocity_targets
    weather = None
    if where_when and where_when.strip():
        from . import weather as wx
        weather = wx.lookup_from_text(where_when)
        if weather.get("ok") and session_temp_f is None:
            session_temp_f = weather["temp_f"]
            weather["used_for_session_temp"] = True
    result["weather"] = weather
    result["velocity_targets"] = compute_velocity_targets(
        cartridge, b_wt, b_len, chrono["avg_fps"], max_psi=max_psi,
        session_temp_f=session_temp_f, shoot_temp_f=shoot_temp_f, barrel_contour=barrel_contour,
        case_h2o_gr=case_h2o_override_gr, coal_in=coal_in,
        temp_coef_fps_per_f=temp_coef_fps_per_f, powder_name=powder_name.strip(),
        daily_band_pct=(daily_lo_pct or 85.0, daily_hi_pct or 90.0),
        hunting_max_pct=hunting_max_pct or 95.0,
    )
    result["grtload_xml"] = build_grtload_xml(result)
    return result
