"""Browser (Pyodide) entry point for Nodie's static build.

Runs the exact same engine as the Python server, but in a Web Worker. No backend:
the only network calls are the optional free weather lookups (Open-Meteo / IEM /
Nominatim), made directly from the browser via synchronous XHR inside the worker.
"""
import json

from nodefinder import weather
from nodefinder.engine import CARTRIDGES
from nodefinder.server import SAMPLE_PRESETS, handle_analyze_request


def _browser_http(url: str) -> str:
    from pyodide.http import open_url  # sync XHR; fine inside a Web Worker
    return open_url(url).getvalue()


weather._http = _browser_http
# lookup_shoot_temp's default arg captured the original _http; rebind defaults too.
weather.geocode.__defaults__ = (_browser_http,)
weather.lookup_shoot_temp.__defaults__ = (_browser_http, True)
weather.lookup_from_text.__defaults__ = (_browser_http, True)


def cartridges_json() -> str:
    return json.dumps({"cartridges": CARTRIDGES, "samples": SAMPLE_PRESETS})


def analyze_json(fields_json: str, files: dict) -> str:
    """fields_json: JSON str of form fields. files: {name: (filename, bytes)}."""
    fields = json.loads(fields_json)
    try:
        return json.dumps({"ok": True, "data": handle_analyze_request(fields, files)})
    except Exception as e:  # mirror server's 400 error payload
        return json.dumps({"ok": False, "data": {"error": str(e)}})
